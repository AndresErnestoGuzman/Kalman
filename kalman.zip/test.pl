
# The test script should run and not print anything if succesful.


use PDL;
use Kalman;
use strict;
 use constant PI    => 4 * atan2(1, 1);
my $eps=1e-15;

my ($N,$m,$l)=(100,2,2);

srand(5583049940); # set a seed, if needed
my $times=qsort(random($N));
my $frequencies=100+300*random($N);
my $Y=grandom($N);

my $parameters={
	'Flux OU number' => $m,
	'SI OU number' => $l,
	'tau_F' => pdl(0.2,0.7),
	'tau_SI' => pdl(0.15,0.6),
	'sigma_F' => pdl(1,3),
	'sigma_SI' => pdl(0.3,0.5),
	'sigma_N' => 0.1,
	'crossCorrs' => pdl([[1.0, 0.2, - 0.3,.1],[0.2, 1.0, 0.5,.1],[- 0.3, 0.5,1.0,0.0],[0.1,0.1,0.0,1.0]]),
	'frequencyHeteroscedasticityIndex' => 0.5 ,
	'Observation' => random(100)>0.7,
	'returnForecastState' => 1,
	'returnFilterState' => 1
};

my ($mm1,$vv1,$argRef1) = Kalman::OU_FSI_gralMix($times,$Y,$frequencies,$parameters);

my $log_likelihood = -0.5 * ($N * log(2 * PI) + sum(log($vv1)) + sum(($Y-$mm1)**2 / $vv1));
#print "Log-likelihood = $log_likelihood\n";

#print("$mm $vv\n");
#print("Kalman filter results:\n",$argRef1->{'Filter'}->{'Xn_n'});
#@_=$argRef1->{'State'}->{'Xn_n-1'}->dims;print"@_\n";
#@_=$argRef1->{'State'}->{'Vn_n-1'}->dims;print"@_\n";

$parameters->{'returnSmoothState'} = 1;
my ($mm2,$vv2,$argRef2) = Kalman::backtrack_smoother_ND($times,$Y,$frequencies,$parameters);
#print "***$Y";wcols($Y,$mm2,$vv2);exit;
#print("Smoothed solutions:\n",$argRef2->{'Smooth'}->{'Xn_N'}); 
#print $argRef1->{'State'}->{'Xn_n-1'}->slice(":,0");
warn "Error. Process is centered by default!\n" unless(sum(abs($argRef1->{'ForecastState'}->{'Xn_n-1'}->slice(":,0"))) < $eps);
warn "Error. Last smoothed solution should be equal to last filter!\n" 
	unless(sum(abs($argRef2->{'SmoothState'}->{'Xn_N'}->slice(":,-1")-$argRef1->{'FilterState'}->{'Xn_n'}->slice(":,-1"))) < $eps);

my ($_auxV);
foreach my $_idx (0..($N-1)){
	$_auxV=$argRef1->{'FilterState'}->{'Vn_n'}->slice(":,:,$_idx")->squeeze;
	warn "Error. Variance matrices of filter should be symmetric! $_auxV\n" 
		if(sum(abs($_auxV-$_auxV->transpose))>$eps);
	$_auxV=$argRef1->{'ForecastState'}->{'Vn_n-1'}->slice(":,:,$_idx")->squeeze;
	warn "Error. Variance matrices of forecasts hould be symmetric! $_auxV\n" 
		if(sum(abs($_auxV-$_auxV->transpose))>$eps);
	$_auxV=$argRef2->{'SmoothState'}->{'Vn_N'}->slice(":,:,$_idx")->squeeze;
	warn "Error. Variance matrices of smoothed solution should be symmetric! $_auxV\n" 
		if(sum(abs($_auxV-$_auxV->transpose))>$eps);
}