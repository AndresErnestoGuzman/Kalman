package Kalman;

use strict;use warnings;
use PDL;

=head1 NAME

PDL::Kalman - routines to calculate Kalman recursions for Gaussian Ornstein-Uhlenbeck finite mixtures.

=head1 SYNOPSIS

	use PDL;
	use Kalman;
	($Yn_nm1,$Vn_nm1,$argRef) = Kalman::OU_FSI_gralMix($times,$Y,$frequencies,$parameters);
	($Yn_N,$Vn_N,$argRef) = Kalman::backtrack_smoother_ND($times,$Y,$frequencies,$parameters);

=head1 DESCRIPTION

Module C<Kalman> has  two subroutines, C<OU_FSI_gralMix> and C<backtrack_smoother_ND>,
which  receives a sampling sequence Y_i (i=1...N), measured at times t_i and frequencies f_i. 
The sampling sequence is modeled as noisy observations from a mixture of Ornstein-Uhlenbeck (OU) processes.
The mixture consist of the addition of 'm' centered Gaussian OU processes 
(representing the flux at a fiducial frequency) and 'l' centered Gaussian OU processes  multiplied by ln(f_i) 
(representing spectral index variability). Independent, Gaussian  noise is added to this  mixture (the measurement noise, sigma_N).

C<OU_FSI_gralMix> 
provides forecasts calculated from a state space representation of the  model using the Kalman recursions. 
The n-th forecast is based on all previous (i=1...n-1) samplings. C<backtrack_smoother_ND> provides the smoothed estimations
at n-th time and its variance but only in case the 'Observation' vector (given in the input hash reference) 
has a zero in the n-th position. Otherwise, C<backtrack_smoother_ND> returns Y_n and a zero variance by default. This is consistent
with the smoothing solution being the best estimation given all the rest of the data.

The code is based on the description of the Kalman recursions given in Kitagawa & Gersh (1996, Chapter 5).
Full description of the model can be found in Guzman et al. (in prep.). 

C<OU_FSI_gralMix> 
 also returns a hash reference  which may include the forecasts and filter of the state representation (and their variance matrices). This 
 output hash reference is empty by default, but it may not be depending on the options provided in the input 
 ('returnForecastState' and 'returnFilterState'). Analogously, C<backtrack_smoother_ND>
returns a hash reference which may include the smoothed solutions and variances of the state  representation. Hash is empty unless the 
'returnSmoothState' key in the input hash reference is set to 1.

=head2 Input

=over 3

=item 1. Ordered times

Sorted piddle of size N with the measurement times.

=item 2. Measurements

Size N piddle with the measured values of the process.

=item 3. Frequencies

Size N posive piddle with the frequencies associated with each measurement.

=item 4. A hash reference with the following keys

I<MANDATORY KEYS>

=over 

=item 'Flux OU number'

Integer 'm' described above. Number of OU processes for the Flux at the fiducial frequency.

=item 'SI OU number'

Integer 'l' described above. Number of OU processes for the spectral index.

=item 'tau_F'

Piddle of size 'm' with the decorrelation times of the Flux OU processes. Time scale is normalized by the total range of the array of times.  

=item 'tau_SI'

Piddle of size 'l' with the decorrelation times of the Spectral Index OU processes. Time scale is   normalized by the total range of the array of times. 

=item 'sigma_F'

Piddle of size 'm' with the square root of the variance rates of the Flux OU processes.

=item 'sigma_SI'

Piddle of size 'l' with the square root of the variance rates of the Spectral Index OU processes.

=item 'sigma_N'

Positive number. Measurement noise at fiducial frequency.   Noise at other frequencies is 'sigma_N'x(frequency/fiducial)^(heteroscedasticity idx)

=back

I<OPTIONAL KEYS> (C<OU_FSI_gralMix> and C<backtrack_smoother_ND>)

=over 

=item  'crossCorrs'

Matrix ((m+l)x(m+l) piddle) of cross correlations between the components of the OU process. Default: identity.

=item 'frequencyHeteroscedasticityIndex'

Spectral index for the noise component. Set to 0.0 by default.

=item 'Observation'						: 

Piddle of size N with ones and zeroes indicating whether an observation took place at that time or not.
Default: N ones.

=item 'Fiducial frequency'				: 

Positive number. Default: 100.

=back

I<OPTIONAL KEYS> (C<OU_FSI_gralMix> only)

=over

=item 'returnForecastState'						: 

Zero or one. Whether to return the state forecasts. Default: 0.

=item 'returnFilterState'						: 

Zero or one. Whether to return the filtered states. Default: 0.

=back

I<OPTIONAL KEYS> (C<backtrack_smoother_ND> only)

=over 

=item 'returnSmoothState'					: 

Zero or one. Whether to return the smoothed states. Default: 0.

=back 

=back

=head2 Output

B<'C<OU_FSI_gralMix>' returns a list with>

=over 3

=item i)   

N dimensional piddle with the forecasts from the finite mixture process defined by the input and the mandatory keys in the input hash reference 

=item ii)  

N dimensional piddle with the associated variances  

=item iii) 

An empty hash reference by default.
If 'returnForecastState' or 'returnFilterState' are set to 1, the latter hash reference
has keys 'ForecastState' and 'FilterState', respectively, defined as:

=over 

=item 'ForecastState' -> 

{

=over 

=item 'Xn_n-1' 

State vector of the forecasts. Dimensions: ((m+l) x N)

=item 'V_n_n-1' 

Variance matrices of the states. Dimensions: ((m+l) x (m+l) x N)

=back

}

=back

=over 

=item 'FilterState' -> 

{

=over 

=item 'Xn_n'

State vector of the forecasts. Dimensions: ((m+l) x N)

=item 'Vn_n'

Variance matrices of the states. Dimensions: ((m+l) x (m+l) x N)

=back

}

=back

=back

B<'C<backtrack_smoother_ND>' returns a list with>

=over 3

=item i)  

N dimensional piddle with the smoothed values of the finite mixture process defined by the input and the mandatory keys in the input hash reference 

=item ii)  

N dimensional piddle with the associated smoothing variances  

=item iii) 

An empty hash reference by default.
If 'returnSmoothState' is set to 1, this hash reference
has key 'SmoothState'  defined as:

=over 

=item 'SmoothState' -> 

{

=over 

=item 'Xn_N'

State vector of the smoothing solution. Dimensions: ((m+l) x N)

=item 'V_n_N'

Variance matrices of the state of the smoothing solution. Dimensions: ((m+l) x (m+l) x N)

=back

}

=back

=back

=head1 FUNCTIONS

=head2 C<OU_FSI_gralMix>

Example code

	!#/usr/bin/perl -w
	use PDL;		# below this line you may copy and paste in PDL prompt
	use Kalman;
	($N,$m,$l)=(10,2,2);
	$times=qsort(random($N));
	$frequencies=100+300*random($N);
	$Y=grandom($N);
	$parameters={
		'Flux OU number' => $m,
		'SI OU number' => $l,
		'tau_F' => pdl(0.2,0.7),
		'tau_SI' => pdl(0.15,0.6),
		'sigma_F' => pdl(1,3),
		'sigma_SI' => pdl(0.3,0.5),
		'sigma_N' => 0.1,
		'returnForecastState' => 1};

	($mm,$vv,$argRef) = Kalman::C<OU_FSI_gralMix>($times,$Y,$frequencies,$parameters);
	print $argRef->{'ForecastState'}->{'Xn_n-1'};

=head2 C<backtrack_smoother_ND>

Example code

	!#/usr/bin/perl -w
	use PDL;		# below this line you may copy and paste in PDL prompt
	use Kalman;
	($N,$m,$l)=(10,2,2);
	$times=qsort(random($N));
	$frequencies=100+300*random($N);
	$Y=grandom($N);
	$parameters={
		'Flux OU number' => $m,
		'SI OU number' => $l,
		'tau_F' => pdl(0.2,0.7),
		'tau_SI' => pdl(0.15,0.6),
		'sigma_F' => pdl(1,3),
		'sigma_SI' => pdl(0.3,0.5),
		'sigma_N' => 0.1,
		'returnSmoothState' => 1};

	($mm,$vv,$argRef) = Kalman::backtrack_smoother_ND($times,$Y,$frequencies,$parameters);
	print $argRef->{'SmoothState'}->{'Xn_N'};

=head1 REFERENCES

Brockwell, P. J.; Davis R. A., Introduction to Time Series and Forecasting (2002)

Guzman, A.E.; Verdugo C.; Nagai, H.; Contreras, Y.; Marinello, G.; Kneissl, R.; Nakanishi, K.; Ueda, J.,  (L<link to paper DOI|https://ascl.net>)

Kelly B. C.; Sobolewska, M.; Siemiginowska, A., 2011 ApJ 730, 52

Kitagawa, G.; Gersch, W.;  Smoothness Priors Analysis of Time Series (1996)

=cut
 
sub OU_FSI_gralMix{

    # 1st argument: the observation times, 2nd arg: the data, 3rd: the frequencies
    # the rest of the arguments are given in the $arg_ref hash
    my($_times,$_Y,$_freqs,$arg_ref)=@_;
    my $m=$arg_ref->{'Flux OU number'};# Dimension of the f matrix (number of OU)
    my $l=$arg_ref->{'SI OU number'}; # Dimension of the beta matrix
    my $_tau_F=$arg_ref->{'tau_F'};die "Dims mismatch! tau_F" unless(nelem($_tau_F)==$m);# f-decorrelation times + consistency test
    my $_tau_SI=$arg_ref->{'tau_SI'};die "Dims mismatch! tau_SI" unless(nelem($_tau_SI)==$l);# beta-decorrelation times + consistency test
    my $_sigma_F=$arg_ref->{'sigma_F'};die "Dims mismatch! sigma_F" unless(nelem($_sigma_F)==$m);# f-variance rate + consistency test
    my $_sigma_SI=$arg_ref->{'sigma_SI'};die "Dims mismatch! sigma_SI" unless(nelem($_sigma_SI)==$l);# beta-variance rate + consistency test
    my $_sigma_N=$arg_ref->{'sigma_N'};# measurement error
    my $fiducial_frequency = 100; $fiducial_frequency = $arg_ref->{'Fiducial frequency'} if defined($arg_ref->{'Fiducial frequency'});
    my $_obs=ones($_Y);$_obs=$arg_ref->{'Observation'} if(defined($arg_ref->{'Observation'})); # Observations vector
    $_Y=$_Y->setbadif($_obs==0); # THIS VALUE SHOULD NOT MATTER. Set to BAD. Value of the data vector when there are no observations 
    
    # these two following lines define the cross correlation matrix 
    my $_crossCorrs=stretcher(ones($m+$l)); # Identity matrix is the default. No cross correlations.
    $_crossCorrs=$arg_ref->{'crossCorrs'} if(defined($arg_ref->{'crossCorrs'})); # Symmetric matrix of cross-correlations between F & SI components.
    warn "Correlation matrix non-symmetric" if(sum(abs($_crossCorrs-$_crossCorrs->transpose))>1e-7);

    # A heteroscedasticity parametrization
    my $fHI=0;$fHI=$arg_ref->{'frequencyHeteroscedasticityIndex'} if defined($arg_ref->{'frequencyHeteroscedasticityIndex'});
    $_sigma_N=($_freqs/$fiducial_frequency)**$fHI*$_sigma_N;#die $_sigma_N;
    
    # Define perl lists from the piddles. The type of algorithm makes it very difficult to work with
    # vectors directly. The 'reverse' is just a matter of taste, in this way we take each value with pop
    # and put them in the resulting arrays with push, but I could have used shif and unshift as well
    my @aux_Y=reverse(list($_Y));# that is, @aux_Y=(y_n,y_(n-1),...,y_2,y_1);
    my @aux_Freq=reverse(list($_freqs));
    my @dtimes=reverse(list(($_times->slice("1:-1"))-($_times->slice("0:-2"))));
    my @aux_sigmaN=reverse(list($_sigma_N));
    my @aux_Obs=reverse(list($_obs));
    # that is, @dtimes=(t_n-t_(n-1),t_(n-1)-t_(n-2),...,t_2-t_1)
    die "Times not well ordered!\n@dtimes\n" if(sum(pdl(@dtimes)<0)>0);# times are assumed to be ordered
    
    # An auxliary subroutine. Not really necessary to define it inside this subroutine.
    local *aux_GGt = sub{
        my ($dt)=@_;#print "freq $freq\n";
        my$__sig=$_sigma_F->append($_sigma_SI);
        my $__exp=zeroes($m+$l);
        my $ttinv=($_tau_F->append($_tau_SI))*(ones($m+$l)->dummy(0));
        $ttinv=(1/ $ttinv + 1/ transpose($ttinv));#
        $__exp= exp(-$dt*$ttinv) if(defined($dt));
        #$__exp=outer($__exp,$__exp);print(1-$__exp,"\n---- $dt") if(defined($dt));
        $__sig=outer($__sig,$__sig);
        my $ccm=$__sig*(1-$__exp)/ $ttinv *$_crossCorrs;
        return($ccm);        
    };

    my $frequency_n=pop(@aux_Freq);
    my $Hn=ones($m)->append(ones($l)*log($frequency_n/$fiducial_frequency));
    my $Xn_nm1=transpose(zeroes($m+$l));
    my $Yn_nm1=($Hn x $Xn_nm1)->squeeze;
    my (@Xpreds,@Ypreds,@Vpreds);# i=1, first time
    push(@Xpreds,$Xn_nm1);push(@Ypreds,$Yn_nm1);
    my $Vn_nm1=aux_GGt();push(@Vpreds,$Vn_nm1);
    my $sN=pop(@aux_sigmaN);
    # Notar que en este paso se establece que la funcion entrega 'r_n' de K&G
    my $auxi=$Vn_nm1 x transpose($Hn); 
    my $vyn=($Hn x $auxi)->squeeze+ $sN**2; die "Definite positiveness! $Vn_nm1 " if(sum($Hn x $auxi)<0);
    #print "vyn= $vyn\n";
    my @vys;
    push(@vys,$vyn);
    my ($Xn_n,@Xfilt,@Vfilt,$Vn_n,$Yn,$dt,$Kn,$Fn,$obs);
    while (@dtimes){
        # FILT
        $obs=pop(@aux_Obs);
        $Kn=zeroes(1,$m+$l);$Kn=$auxi/$vyn if($obs);#print "obs=$obs; Kn=$Kn\n";
        $Yn=pop(@aux_Y);
        if(pdl($Yn)->PDL::Bad::isgood){
            $Xn_n=$Xn_nm1+$Kn*($Yn-$Hn x $Xn_nm1);
        }
        else{
            $Xn_n=$Xn_nm1;
        }
        $Vn_n=$Vn_nm1-$Kn x $Hn x $Vn_nm1;
        if(0){my($ev,$e)=eigens($Vn_nm1);die "!!eigs Vn_n-1: $Vn_nm1 $e"if(sum($e<0));}#test
        #($ev,$e)=eigens($Vn_n);die "!!eigs Vn_n: $Vn_n $_"if(sum($e<0));
        #(pdl([[1,0],[0,1]])-$Kn x $Hn) x $Vn_nm1;
        #print "-- Vn_n -- $Vn_n\n" if(sum(($Vn_n-transpose($Vn_n))**2));
        if($arg_ref->{'returnFilterState'}){push(@Xfilt,$Xn_n);push(@Vfilt,$Vn_n)}

        # PRED
        $dt=pop(@dtimes);
        $Fn=aux_Ft($dt,$_tau_F,$_tau_SI);
        $Xn_nm1=$Fn x $Xn_n;#die ("---- ",$dt,$Fn);
        $Vn_nm1=$Fn x $Vn_n x transpose($Fn) + aux_GGt($dt);
        if($arg_ref->{'returnForecastState'}){push(@Xpreds,$Xn_nm1);push(@Vpreds,$Vn_nm1);}
        $frequency_n=pop(@aux_Freq);
        $Hn=ones($m)->append(ones($l)*log($frequency_n/$fiducial_frequency));#print" $Hn $Vn_nm1";
        $Yn_nm1=($Hn x $Xn_nm1)->squeeze; 
        push(@Ypreds,$Yn_nm1);
        #### test! ,pdl(@Vfilt)->clump(2),pdl(@Yfilt)->clump(2)
        #push(@Yfilt,($Hn x $Xn_n)->squeeze);
        #### test!
        $sN=pop(@aux_sigmaN);
        $auxi=$Vn_nm1 x transpose($Hn); #print " $dt \$auxi=$auxi\n"; die if (sum(PDL::Bad::isgood($auxi->setnantobad))<3);
        $vyn=($Hn x $auxi)->squeeze+ $sN**2;die "Definite positiveness! $Vn_nm1 $auxi $Hn" if(sum($Hn x $auxi)<0);#$Hn x $Vn_nm1 x transpose($Hn)+ $sN**2;
        push(@vys,$vyn);
        }
    # LAST FILTER
    if($arg_ref->{'returnFilterState'}){
        $obs=pop(@aux_Obs);
        $Kn=zeroes(1,$m+$l);$Kn=$auxi/ $vyn if($obs);
        $Yn=pop(@aux_Y);
        if(pdl($Yn)->PDL::Bad::isgood){
            $Xn_n=$Xn_nm1+$Kn*($Yn-$Hn x $Xn_nm1);
        }
        else{
            $Xn_n=$Xn_nm1;
        }
        $Vn_n=$Vn_nm1-$Kn x $Hn x $Vn_nm1;
        my($ev,$e)=eigens($Vn_nm1);die "!!eigs Vn_n-1: $Vn_nm1 $e"if(sum($e<0));
        push(@Xfilt,$Xn_n);push(@Vfilt,$Vn_n);
    }
    my $rarg={};
    # Last index 
    $$rarg{'ForecastState'}={'Xn_n-1'=>pdl(@Xpreds)->clump(2),'Vn_n-1'=>pdl(@Vpreds)}
         if($arg_ref->{'returnForecastState'});
    $$rarg{'FilterState'}={'Xn_n'=>pdl(@Xfilt)->clump(2),'Vn_n'=>pdl(@Vfilt)}
        if($arg_ref->{'returnFilterState'});
     return(pdl(@Ypreds)->squeeze,pdl(@vys)->squeeze,$rarg);
}

sub backtrack_smoother_ND{
    my($_times,$_Y,$_freqs,$arg_ref)=@_;
    
    my $m=$arg_ref->{'Flux OU number'};
    my $l=$arg_ref->{'SI OU number'};
    my $_tau_F=$arg_ref->{'tau_F'};die "Dims mismatch! tau_F" unless(nelem($_tau_F)==$m);
    my $_tau_SI=$arg_ref->{'tau_SI'};die "Dims mismatch! tau_SI" unless(nelem($_tau_SI)==$l);
    my $_sigma_F=$arg_ref->{'sigma_F'};die "Dims mismatch! sigma_F" unless(nelem($_sigma_F)==$m);
    my $_sigma_SI=$arg_ref->{'sigma_SI'};die "Dims mismatch! sigma_SI" unless(nelem($_sigma_SI)==$l);
    my $_sigma_N=$arg_ref->{'sigma_N'};# measurement error
    my $fiducial_frequency = 100; $fiducial_frequency = $arg_ref->{'Fiducial frequency'} if defined($arg_ref->{'Fiducial frequency'});
    my $_obs=ones($_Y);$_obs=$arg_ref->{'Observation'} if(defined($arg_ref->{'Observation'}));
    
    # Extra care with the assignment operator. Avoid overwrite user input. 
    my $Y=$_Y->copy;
    $_=$Y->where($_obs==0);$_.=-999; # This value, blanked to -999, should not matter.
    
    my $_crossCorrs=stretcher(ones($m+$l));
    $_crossCorrs=$arg_ref->{'crossCorrs'} if(defined($arg_ref->{'crossCorrs'})); # Symmetric matrix of cross-correlations between F & SI components.
    warn "Correlation matrix non-symmetric" if(sum(abs($_crossCorrs-$_crossCorrs->transpose))>1e-7);

    # A heteroscedasticity parametrization
    my $fHI=0;$fHI=$arg_ref->{'frequencyHeteroscedasticityIndex'} if defined($arg_ref->{'frequencyHeteroscedasticityIndex'});
    $_sigma_N=($_freqs/$fiducial_frequency)**$fHI*$_sigma_N;# $_sigma_N;
    
    my @dtimes=(list(($_times->slice("1:-1"))-($_times->slice("0:-2"))));
    my $dtimes=pdl(@dtimes);
    die "Times not well ordered!\n@dtimes\n" if(sum(pdl(@dtimes)<0)>0);

    $$arg_ref{'returnFilterState'}=1; $$arg_ref{'returnForecastState'}=1;
    my ($Ypreds,$rn,$PD)=OU_FSI_gralMix($_times,$Y,$_freqs,$arg_ref);
    my ($Xfilts,$Vfilts)=($PD->{'FilterState'}->{'Xn_n'},$PD->{'FilterState'}->{'Vn_n'});
    my ($Xpreds,$Vpreds)=($PD->{'ForecastState'}->{'Xn_n-1'},$PD->{'ForecastState'}->{'Vn_n-1'});
    #@_=$Vfilts->dims;die "::: @_\n";

    my $N=nelem($_times);die "Too few points.\n" unless $N>3; 
    my ($Xs_np1,$Vs_np1,$Vnn,$V_np1_n,$F_np1,$An,$Xnn,$X_np1_n,$Xsn,$Vsn,
        @Xsmooths,@Vsmooths,$Hn,$Ysn,@Ysmooths,$vysn,@vysmooths,$sN,$obs);

    $Xs_np1 = $Xfilts->slice(":,(".($N-1).")")->transpose;
    $Vs_np1 = $Vfilts->slice(":,:,(".($N-1).")");#print $Vs_np1;
    foreach my $i (reverse(0..($N-2))) { 
        my $n=$i+1;
        $Vnn      = $Vfilts->slice(":,:,($i)");
        $V_np1_n  = $Vpreds->slice(":,:,($n)");#print $V_np1_n;
        $F_np1    = aux_Ft($dtimes->slice("($i)"),$_tau_F,$_tau_SI);
        $An       = $Vnn x $F_np1 x pseudoinverse_sym($V_np1_n);# matrix
        $Xnn      = $Xfilts->slice(":,($i)")->transpose;
        $X_np1_n  = $Xpreds->slice(":,($n)")->transpose;
        $Xsn      = $Xnn + $An x ($Xs_np1 - $X_np1_n);
        $Vsn      = $Vnn + $An x ($Vs_np1 - $V_np1_n) x transpose($An);#print "Vsn= $Vsn";
        #print((pseudoinverse_sym($V_np1_n)  x $V_np1_n), "Vsn = $Vsn ;\nVnn = $Vnn\n");#,PDL::MatrixOps::eigens $Vsn);
        if($$arg_ref{'returnSmoothState'}){push(@Xsmooths,$Xsn);push(@Vsmooths,$Vsn);}
        $obs      = $_obs->slice("($i)");
        if($obs){
        	$Ysn      = $_Y->slice("($i)");
        	$vysn     = 0;
        }
        else{
	        $Hn       = ones($m)->append(ones($l)*log($_freqs->slice("($i)")/$fiducial_frequency));#print "Hn = $Hn";
	        $sN       = $_sigma_N->slice("($i)");
	        $Ysn      = ($Hn x $Xsn)->squeeze; 
	        # The following sum in quadrature  is justified only in the case there is NO observation
	        # (or the observation is NOT considered) at time 'i'. 
	        $vysn     = ($Hn x $Vsn x transpose($Hn))->squeeze + $sN**2;    
    	}
    	push(@Ysmooths,$Ysn);push(@vysmooths,$vysn);#print "vysn = $vysn";

        $Xs_np1   = $Xsn;
        $Vs_np1   = $Vsn;
    }
    # Last smoothing is equal to the last filter, which is equal to the last prediction in case of no observation
    
    $sN     = $_sigma_N->slice($N-1);
    $Xsn    = $Xfilts->slice(":,(-1)")->transpose; 
    $Vsn    = $Vfilts->slice(":,:,(-1)");

	$obs    = $_obs->slice("(-1)");
	if($obs){
		$Ysn      = $_Y->slice("(-1)");
        $vysn     = 0;
	}
	else{
	    $Hn     = ones($m)->append(ones($l)*log($_freqs->slice($N-1)/$fiducial_frequency))->squeeze;
	    $Ysn    = ($Hn x $Xsn)->squeeze; 
	    # The following sum in quadrature  is justified only in the case there is NO observation
	    # (or the observation is NOT considered) at time 'i'. 
		$vysn   = ($Hn x $Vsn x transpose($Hn))->squeeze + $sN**2;
	}
    unshift(@vysmooths,$vysn);unshift(@Ysmooths,$Ysn);#  unshift instead of push

    my $rarg={};
    if($$arg_ref{'returnSmoothState'}){
        unshift(@Vsmooths,$Vsn);unshift(@Xsmooths,$Xsn);
    	$$rarg{'SmoothState'}={'Xn_N'=>pdl(reverse(@Xsmooths))->clump(2),'Vn_N'=>pdl(reverse(@Vsmooths))};
    }
    return(pdl(reverse(@Ysmooths))->squeeze,pdl(reverse(@vysmooths))->squeeze,$rarg);
}

#######################################################################################
### AUXILIARY SUBROUTINES
#######################################################################################

sub aux_Ft  { # https://www.perlmonks.org/?node_id=696592
        my ($dt,$tF,$tSI)=@_; 
        return PDL::MatrixOps::stretcher(exp(-$dt/ $tF)->append(exp(-$dt/ $tSI)));
    }
sub pseudoinverse_sym{
    my ($m)=@_;$m=$m->copy;
    die "Not symmetric! $m".sum(($m-transpose($m))**2) if(sum(($m-transpose($m))**2)>1e-15);
    @_=$m->dims;my $order=$_[0];
    my $aux;
    $_=sum(abs($m-(PDL::MatrixOps::identity($order))*$m));
    if($_){
        my($ev,$_e)=PDL::MatrixOps::eigens($m);
        my $e=$_e->copy;
        $aux=$e->where($e);
        $aux.=1/$aux;
        return($ev x PDL::MatrixOps::stretcher($e) x transpose($ev));
    }
    else{
        $aux=$m->where($m);$aux.=1/$aux;
        return($m);
    }
}

1;